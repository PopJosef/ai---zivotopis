<?php
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
$prompt = $input['prompt'] ?? '';

$apiKey = 'TVŮJ_API_KLÍČ'; // <-- ZDE VLOŽ SVŮJ KLÍČ

$options = [
  'http' => [
    'method'  => 'POST',
    'header'  => [
      'Content-Type: application/json',
      'Authorization: Bearer ' . $apiKey,
    ],
    'content' => json_encode([
      'model' => 'gpt-3.5-turbo',
      'messages' => [
        ['role' => 'user', 'content' => $prompt]
      ],
      'temperature' => 0.7
    ]),
  ],
];

$context  = stream_context_create($options);
$response = file_get_contents('https://api.openai.com/v1/chat/completions', false, $context);
$data = json_decode($response, true);
$zivotopis = $data['choices'][0]['message']['content'] ?? 'Nepodařilo se vygenerovat.';

echo json_encode(['zivotopis' => $zivotopis]);
?>
